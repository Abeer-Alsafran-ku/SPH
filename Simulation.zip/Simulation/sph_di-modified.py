'''
 
Implemementation of (ISPH) Density Invariant​ Smoothed Particle Hydrodynamics.

Auther: Latifah Almutairi & Abeer Alsafran
date: 12 Nov 2024

'''
import math 
import numpy as np
import random
from sklearn.neighbors import NearestNeighbors
############### initial conditions ######################
g = 9.81 # gravity connstant
h = 0.01 # Smoothing length
c = 1500 # Speed of light in medium (water assumed)
C_cfl = 1.15 
dt = C_cfl*h/c # delta time from CFL condition
height = 3 
width = 10
n = math.ceil(height*width/3.14/math.pow(h,2))  # Number of Particles
rho = 1000 # constant rho
mu = 0.0010016 #at temp  20
nu = mu / rho #  
V_in_lam = 2300 * mu / height / rho # Re = rho V D / mu > V = 2300 * mu / (D * rho) [laminar Flow]
v0 = np.array([V_in_lam,0,0]) #initial value of velocity assumed
fg = -g * np.array([0,1,0])
number_of_particles =  math.ceil(height*width/math.pi/math.pow(h,2)) # [2D]
total_mass_of_the_system = rho * height * width
mj  = total_mass_of_the_system / number_of_particles # const

'''Initial coordinates at time = 0'''
initial_r = height-2*h / number_of_particles*2.5
coordinates = np.array([])
coordinates[0][0] = 0
for i in range(1, number_of_particles): # create the initial coordinates 
    coordinates[0][i] = coordinates[0][i-1] + initial_r
      
 


############### End of initial conditions ################


################# DEFs ###################

# this function will calculate: 
# W: smoothing particle for a specific r 

def calc_W(r,h):
    w = np.array([])
    for i in range(1,n):
        r = np.append(r,i)
        s = np.linalg.norm(r[i]) / h # = q
        if s >=0 and s <=1:
            w[i] = 15 / 7 / math.pi / math.pow(h,2) * (2/3 - 9/8 * math.pow(s,2) + 19/ 24 * math.pow(s,3) - 5/32 * math.pow(s,4))
        else: # added 
            s = 1 
            w[i] = 15 / 7 / math.pi / math.pow(h,2) * (2/3 - 9/8 * math.pow(s,2) + 19/ 24 * math.pow(s,3) - 5/32 * math.pow(s,4))
    return w


def calc_del_W(rij,h): # input: vector
    # s is not defined # here
	del_W = rij.copy() * 15 / 7 / math.pi / math.pow(h,4) * (- 9/4 + 19/ 8 * s - 5/8 * math.pow(s,2))

	return del_W


def calc_viscous_i(rij, vij): #input: vectors
	
	del_Wij = calc_del_W(rij,h).copy()
	term_r_delW = np.dot(rij.copy(), del_Wij.copy())
	rij_n = np.linalg.norm(rij.copy())
	term_viscous_i = mj * mu ( 2 / math.pow(rho, 2) ) * vij.copy() * term_r_delW  / ( math.pow(rij_n, 2) + math.pow(eta, 2))

	return term_viscous_i
	
def calc_viscous_f(rij, vij): #input: Matrices
	nu_del2vi = [0, 0, 0]
    
	for i in range(len(rij)):
		nu_del2vi += calc_viscous_i(rij[i,:], vij[i,:]).copy()
		
	return nu_del2vi

def step_1_i(v_i_n, rij, vij): # vector, Matrix, Matrix
	
	fv = calc_viscous_f(rij, vij).copy()
	F = fg.copy() + fv.copy()
	v_i_prime = v_i_n.copy() + F.copy() * dt

	return v_i_prime
	
	

############ End of DEF #################


# Main Loop


############### Neighbour Algorithm ##################

# Number of neighbors
k = 5  

# Initialize the NearestNeighbors model
nbrs = NearestNeighbors(n_neighbors=k, algorithm='auto').fit(coordinates)

distances, indices = nbrs.kneighbors(np.array([coordinates[0]]))

r =np.array([]) 

for i in range(len(indices[0])):
  #print(coordinates[indices[0][i]])
  r[i] = distances[0][i]


# calculate the r (radius) = ri - rj 
# r: distance with direction | initial location per particle 

############### end of Neighbour Algorithm ###########



############### step 1 ##################




################################################## dynamic 
'''
rho = summation j = 1 to n [mj * Wij]

'''

#vij = vi - vj 

#rij = ri - rj # r rij
eta = 0.01 * h 

'''
w is the smoothing particle 
'''

r = np.array([0]) #assumed  
rho= 0
w = np.array([])
for i in range(1,n):
    r = np.append(r,i)
    s = math.fabs(r[i]) / h
    w[i] = calc_W(r,h)
    rho += mj * w[i]  
################################# dynamic for each particle 
'''
delta t <= C(cfl) * h / V + c 

assume c >> V 

delta t <= C(cfl) * h / c

C(cfl) = [0.1, 0.3]

(small c is the speed of the sound in medium assumed the medium is water) 
'''

delta_t = (C_cfl * h )/c 


number_of_steps = 1 / delta_t 


delta_v = 1 # derivative 
''' 
vi = np.array([0])
for i in range(1,n): 
    vi_temp = v0[0] +(  (1/rho) * (mu * delta_v) + fg )  
    vi = np.append(vi , vi_temp)
vi = vi * delta_t
'''

v_prime = []
for i in range(1,n): #here
	v_prime.append(step_1_i(v_i_n, rij, vij).copy()) # All points, Matrix
	
######## end of step 1 ##################




############### step 2 ##################
'''
ri = ri_n + vi . delta t 
'''
ri_0 = np.copy(r) # to be calculated
ri = np.array([0]) # final result of step 2
for i in range(1,n):
    r_tmp = ri_0[i] + (v_prime[i] * delta_t) # r is a vector
    ri = np.append(ri,r_tmp)

######## end of step 2 ##################


############### step 3 ##################
'''
Pi to n+1 <- delta . (delta Pi to n+1) 
= rho0 - rho_dash_i / rho0 delta t^2  
rho = rho_i = summation j = 1 to N (mj * wij) 
summation j = 1 to N (mj) (8/rhoi + rhoj)^2 . Pij rij Wij (rij , h) / (||rij||)^2+ata^2
'''
rho_ij = rho + rho
alpha = np.array([])
w_i= calc_W(ri,h)
p_i = 1 # constant 
for i in range (1, n):
    alpha[i] = mj * (8 / math.pow(rho_ij,2)) * ((p_i * ri[i] * w_i[i]) 
                                              / 
                                    (math.pow(ri[i],2) + math.pow(eta,2)))
A_i = np.array([])
for i in range(i,n):
    A_i[i] = alpha[i] * p_i
    
# p = alpha inverse * A
# A = alpha_a * p_a + summation j =1 to N (alpha_j * p_j )
h_ij = (height + height) / 2
normal = 1 # to be calc 

#mini = min(((vi - vj) * normal) , -1)
#boundry_treatment = - ( math.pow(v,2)  * w[i] * math.pow(h_ij,2) * normal * mini)

######## end of step 3 ##################


############### step 4 ##################


############### end of step 4 ###########




############### step 5 ##################

############### end of step 5 ###########



############### step 6 ##################


############### end of step 6 ###########
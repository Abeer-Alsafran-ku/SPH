'''
this is the first approach of implementing 
(ISPH) Density Invariant​ 

Auther: Abeer Alsafran
date: 12 Nov 2024

'''
import math 
import numpy as np
############### initial conditions ######################

presure  = 2

velocity = 4

n = 10000

g = 9.81 

h = 0.01

c = 1500 

C_cfl = 1.15

height = 3

width = 10

rho_const = 1000

v0 = np.array([4,0,0]) #initial value of velocity assumed

miu = 0.0010016 #at temp  20

############### End of initial conditions ################

################# DEFs ###################
# this function will calculate the 
# W: smoothing particle for a specific
# r 
def calc_W(r,h):
    w = np.array([])
    for i in range(1,n):
        r = np.append(r,i)
        s = math.fabs(r[i]) / h
        w[i] = ( (15 / (7 * math.pi * (math.pow(h,2)) ))  * 
            (
                ( (2/3) - ( (9/8) *( math.pow(s,2)) )) +
                ( (19/24) * ( (math.pow(s,3))) ) - 
                ((5/32) * math.pow(s,4))
            )
            )
    return w


############ End of DEF #################

############### step 1 ##################
'''
v_i = v_i_n + [1/rho] delta (miu delta v) + f] from i to n . delta t;
'''
v_i_n = np.copy(v0) #copy 

f = -g * np.array([0,1,0]) #vector  

'''[1/rho] delta (miu delta v) ]'''
total_mass_of_the_system = rho_const * height * width

'''
number_of_particles = total_area_of_domain / area_of_particle [2D]
number_of_particles = total_volume / volume_of_particle [3D]
'''

number_of_particles = (height * width ) / ( math.pi * math.pow(h,2) ) # [2D]

mj  = total_mass_of_the_system / number_of_particles

################################################## dynamic 
'''
rho = summation j = 1 to n [mj * Wij]
'''

#vij = vi - vj 

#rij = ri - rj # r rij
eta = 0.01 * h 

'''
w is the smoothing particle 
'''

r = np.array([0]) #assumed  
rho= 0
w = np.array([])
for i in range(1,n):
    r = np.append(r,i)
    s = math.fabs(r[i]) / h
    w = calc_W(r,h)
    rho += mj * w[i]  
################################# dynamic for each particle 
'''
delta t <= C(cfl) * h / V + c 

assume c >> V 

delta t <= C(cfl) * h / c

C(cfl) = [0.1, 0.3]

(small c is the speed of the sound in medium assumed the medium is water) 
'''

delta_t = (C_cfl * h )/c 


number_of_steps = 1 / delta_t 


delta_v = 1 # derivative  
vi = np.array([0])
for i in range(1,n): 
    vi_temp = v0[0] +(  (1/rho) * (miu * delta_v) + f )  
    vi = np.append(vi , vi_temp)
vi = vi * delta_t


######## end of step 1 ##################




############### step 2 ##################
'''
ri = ri_n + vi . delta t 
'''
ri_0 = np.copy(r) # to be calculated
ri = np.array([0])
for i in range(1,n):
    r_tmp = ri_0[i] + (vi[i] * delta_t) # r is a vector
    ri = np.append(ri,r_tmp)

######## end of step 2 ##################


############### step 3 ##################
'''
Pi to n+1 <- delta . (delta Pi to n+1) 
= rho0 - rho_dash_i / rho0 delta t^2  
rho = rho_i = summation j = 1 to N (mj * wij) 
summation j = 1 to N (mj) (8/rhoi + rhoj)^2 . Pij rij Wij (rij , h) / (||rij||)^2+ata^2
'''
rho_ij = rho + rho
alpha = np.array([])
w_i= calc_W(ri,h)
p_i = 1 # constant 
for i in range (1, n):
    alpha[i] = mj * (8 / math.pow(rho_ij,2)) * ((p_i * ri[i] * w_i[i]) 
                                              / 
                                    (math.pow(ri[i],2) + math.pow(eta,2)))
A_i = np.array([])
for i in range(i,n):
    A_i[i] = alpha[i] * p_i
    
# p = alpha inverse * A
# A = alpha_a * p_a + summation j =1 to N (alpha_j * p_j )
h_ij = (height + height) / 2
normal = 1 # to be calc 

#mini = min(((vi - vj) * normal) , -1)
#boundry_treatment = - ( math.pow(v,2)  * w[i] * math.pow(h_ij,2) * normal * mini)

######## end of step 3 ##################


############### step 4 ##################


############### end of step 4 ###########




############### step 5 ##################

############### end of step 5 ###########



############### step 6 ##################


############### end of step 6 ###########